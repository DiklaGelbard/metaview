library(testthat)
library(tgconfig)

test_check("tgconfig")
