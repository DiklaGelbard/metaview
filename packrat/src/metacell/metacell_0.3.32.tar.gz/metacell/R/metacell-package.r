#' metacell
#'
#' @import dplyr
#' @import ggplot2
#' @import tgconfig
#' @import tgstat
#' @import tgutil
#' @import igraph
#' @importFrom pdist pdist
#' @importFrom cluster silhouette
#' @name metacell
#' @docType package
NULL
