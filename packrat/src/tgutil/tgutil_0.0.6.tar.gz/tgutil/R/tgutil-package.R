#' tgutil.
#'
#' @name tgutil
#' @docType package
#' @import tibble
#' @importFrom magrittr %>%
NULL
